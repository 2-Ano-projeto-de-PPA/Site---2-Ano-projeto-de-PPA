/* ============================================================
   MUSEU DIGITAL — RIO DE CONTAS
   script.js — funcionalidades compartilhadas entre as páginas
   ============================================================ */

/* ---- código original do projeto (mantido como estava) ---- */
const folha = `
  <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M 100 170
         C 20 130, 25 50, 100 25
         C 175 50, 180 130, 100 170 Z"
      fill="#66BB6A"
      stroke="#2E7D32"
      stroke-width="2"
    />

    <path
      d="M 100 170 C 95 115, 100 65, 100 25"
      fill="none"
      stroke="#2E7D32"
      stroke-width="2"
    />
  </svg>
`;

/* ------------------------------------------------------------
   Inicialização
   ------------------------------------------------------------ */
document.addEventListener("DOMContentLoaded", () => {
  initNavToggle();
  initFooterYear();
  if (document.querySelector("[data-gallery-root]")) {
    initGallery();
  }
});

/* ------------------------------------------------------------
   Menu de navegação responsivo (usado em todas as páginas)
   ------------------------------------------------------------ */
function initNavToggle() {
  const toggle = document.querySelector("[data-nav-toggle]");
  const links = document.querySelector("[data-nav-links]");
  if (!toggle || !links) return;

  toggle.addEventListener("click", () => {
    const isOpen = links.classList.toggle("is-open");
    toggle.setAttribute("aria-expanded", String(isOpen));
  });

  links.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      links.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
    });
  });
}

/* Preenche automaticamente o ano no rodapé (evita deixar "© 2024" desatualizado) */
function initFooterYear() {
  document.querySelectorAll("[data-year]").forEach((el) => {
    el.textContent = new Date().getFullYear();
  });
}

/* ------------------------------------------------------------
   Dados das fotografias da galeria
   ------------------------------------------------------------
   Estas entradas usam ilustrações de espaço reservado (img/ph-*.svg).
   Para usar uma foto real, basta trocar "src" pelo caminho do arquivo
   (ex.: "img/serra-01.jpg") e preencher fotografo / data / descricao.
   O carrossel e o mural são montados automaticamente a partir desta lista. */
const FOTOS = [
  { src: "img/ph-serra.svg", alt: "Ilustração da serra ao entardecer",
    titulo: "Serra da Chapada Diamantina", local: "Rio de Contas, Bahia",
    fotografo: "Nome do fotógrafo", data: "Data do registro",
    descricao: "Breve descrição da fotografia." },
  { src: "img/ph-rio.svg", alt: "Ilustração de ondulações de um rio",
    titulo: "Águas do Rio de Contas", local: "Bacia do Rio de Contas, Bahia",
    fotografo: "Nome do fotógrafo", data: "Data do registro",
    descricao: "Breve descrição da fotografia." },
  { src: "img/ph-flora.svg", alt: "Ilustração de folhagem ribeirinha",
    titulo: "Folhagem às margens do rio", local: "Bacia do Rio de Contas, Bahia",
    fotografo: "Nome do fotógrafo", data: "Data do registro",
    descricao: "Breve descrição da fotografia." },
  { src: "img/ph-fauna.svg", alt: "Ilustração de peixes do rio",
    titulo: "Vida aquática da bacia", local: "Bacia do Rio de Contas, Bahia",
    fotografo: "Nome do fotógrafo", data: "Data do registro",
    descricao: "Breve descrição da fotografia." },
  { src: "img/ph-casario.svg", alt: "Ilustração do casario histórico",
    titulo: "Casario histórico", local: "Rio de Contas, Bahia",
    fotografo: "Nome do fotógrafo", data: "Data do registro",
    descricao: "Breve descrição da fotografia." },
  { src: "img/ph-horizonte.svg", alt: "Ilustração de horizonte sobre a água",
    titulo: "Horizonte sobre o rio", local: "Bacia do Rio de Contas, Bahia",
    fotografo: "Nome do fotógrafo", data: "Data do registro",
    descricao: "Breve descrição da fotografia." },
  { src: "img/ph-gota.svg", alt: "Ilustração de uma gota de água",
    titulo: "Uma gota d'água", local: "Bacia do Rio de Contas, Bahia",
    fotografo: "Nome do fotógrafo", data: "Data do registro",
    descricao: "Breve descrição da fotografia." },
  { src: "img/ph-trilha.svg", alt: "Ilustração de trilha na Chapada",
    titulo: "Trilhas da Chapada", local: "Rio de Contas, Bahia",
    fotografo: "Nome do fotógrafo", data: "Data do registro",
    descricao: "Breve descrição da fotografia." }
];

/* ------------------------------------------------------------
   Galeria (página museuFotos.html)
   ------------------------------------------------------------ */
function initGallery() {
  renderCarousel();
  renderMural();
  initCarouselControls();
  initLupaModal();
  initMuralReveal();
}

let carouselIndex = 0;
const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

function renderCarousel() {
  const track = document.querySelector("[data-carousel-track]");
  const dotsWrap = document.querySelector("[data-carousel-dots]");
  if (!track || !dotsWrap) return;

  track.innerHTML = FOTOS.map((foto) => `
    <div class="carousel__slide">
      <img src="${foto.src}" alt="${foto.alt}">
      <p class="carousel__caption">${foto.titulo}</p>
    </div>
  `).join("");

  dotsWrap.innerHTML = FOTOS.map((_, i) => `
    <button class="carousel__dot${i === 0 ? " is-active" : ""}" data-dot="${i}" aria-label="Ir para a fotografia ${i + 1}"></button>
  `).join("");
}

function initCarouselControls() {
  const carousel = document.querySelector("[data-carousel]");
  const track = document.querySelector("[data-carousel-track]");
  const dotsWrap = document.querySelector("[data-carousel-dots]");
  const prevBtn = document.querySelector("[data-carousel-prev]");
  const nextBtn = document.querySelector("[data-carousel-next]");
  if (!carousel || !track) return;

  function goTo(index) {
    carouselIndex = (index + FOTOS.length) % FOTOS.length;
    track.style.transform = `translateX(-${carouselIndex * 100}%)`;
    dotsWrap.querySelectorAll("[data-dot]").forEach((dot, i) => {
      dot.classList.toggle("is-active", i === carouselIndex);
    });
  }

  prevBtn?.addEventListener("click", () => goTo(carouselIndex - 1));
  nextBtn?.addEventListener("click", () => goTo(carouselIndex + 1));

  dotsWrap.addEventListener("click", (e) => {
    const dot = e.target.closest("[data-dot]");
    if (dot) goTo(Number(dot.dataset.dot));
  });

  carousel.setAttribute("tabindex", "0");
  carousel.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft") goTo(carouselIndex - 1);
    if (e.key === "ArrowRight") goTo(carouselIndex + 1);
  });

  /* arrastar/deslizar no toque */
  let touchStartX = null;
  track.addEventListener("touchstart", (e) => { touchStartX = e.touches[0].clientX; }, { passive: true });
  track.addEventListener("touchend", (e) => {
    if (touchStartX === null) return;
    const delta = e.changedTouches[0].clientX - touchStartX;
    if (Math.abs(delta) > 40) goTo(carouselIndex + (delta < 0 ? 1 : -1));
    touchStartX = null;
  });

  /* avanço automático, pausado ao interagir ou com redução de movimento ativa */
  let autoplay;
  function startAutoplay() {
    if (prefersReducedMotion) return;
    autoplay = setInterval(() => goTo(carouselIndex + 1), 6000);
  }
  function stopAutoplay() { clearInterval(autoplay); }

  carousel.addEventListener("mouseenter", stopAutoplay);
  carousel.addEventListener("mouseleave", startAutoplay);
  carousel.addEventListener("focusin", stopAutoplay);
  carousel.addEventListener("focusout", startAutoplay);

  startAutoplay();
}

/* ---- mural de fotografias ---- */
const MURAL_SIZES = ["wide", "square", "tall", "square", "wide"];
const MURAL_COUNT = 20;

function renderMural() {
  const mural = document.querySelector("[data-mural]");
  if (!mural) return;

  let html = "";
  for (let i = 0; i < MURAL_COUNT; i++) {
    const foto = FOTOS[i % FOTOS.length];
    const size = MURAL_SIZES[i % MURAL_SIZES.length];
    html += `
      <figure class="mural__item mural__item--${size}" data-foto-index="${i % FOTOS.length}" tabindex="0" role="button" aria-label="Ver informações: ${foto.titulo}">
        <img src="${foto.src}" alt="${foto.alt}" loading="lazy">
      </figure>
    `;
  }
  mural.innerHTML = html;
}

function initMuralReveal() {
  const items = document.querySelectorAll("[data-mural] .mural__item");
  if (!items.length) return;

  if (prefersReducedMotion || !("IntersectionObserver" in window)) {
    items.forEach((item) => item.classList.add("is-visible"));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  items.forEach((item, i) => {
    item.style.transitionDelay = `${(i % 6) * 70}ms`;
    observer.observe(item);
  });
}

/* ---- modal "lupa" com informações da fotografia ---- */
function initLupaModal() {
  const modal = document.querySelector("[data-photo-modal]");
  const lupaBtn = document.querySelector("[data-lupa]");
  if (!modal) return;

  const img = modal.querySelector("[data-modal-img]");
  const title = modal.querySelector("[data-modal-title]");
  const fotografo = modal.querySelector("[data-modal-fotografo]");
  const local = modal.querySelector("[data-modal-local]");
  const data = modal.querySelector("[data-modal-data]");
  const descricao = modal.querySelector("[data-modal-descricao]");
  let lastFocused = null;

  function openModal(foto) {
    img.src = foto.src;
    img.alt = foto.alt;
    title.textContent = foto.titulo;
    fotografo.textContent = foto.fotografo;
    local.textContent = foto.local;
    data.textContent = foto.data;
    descricao.textContent = foto.descricao;

    lastFocused = document.activeElement;
    modal.hidden = false;
    modal.querySelector("[data-modal-close]")?.focus();
    document.addEventListener("keydown", onKeydown);
  }

  function closeModal() {
    modal.hidden = true;
    document.removeEventListener("keydown", onKeydown);
    lastFocused?.focus();
  }

  function onKeydown(e) {
    if (e.key === "Escape") closeModal();
  }

  lupaBtn?.addEventListener("click", () => openModal(FOTOS[carouselIndex]));

  document.querySelectorAll("[data-mural] .mural__item").forEach((item) => {
    const abrir = () => openModal(FOTOS[Number(item.dataset.fotoIndex)]);
    item.addEventListener("click", abrir);
    item.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); abrir(); }
    });
  });

  modal.querySelectorAll("[data-modal-close]").forEach((el) => el.addEventListener("click", closeModal));
}
